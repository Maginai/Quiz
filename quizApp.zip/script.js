document.addEventListener('DOMContentLoaded', () => {
    alert("Quiz prêt à jouer !");
});
