const questions = [
    { question: "Qui a peint la Joconde ?", answers: ["Leonard de Vinci", "Pablo Picasso", "Vincent Van Gogh", "Claude Monet"], correct: 0 },
    { question: "Quelle est la capitale de la France ?", answers: ["Paris", "Berlin", "Madrid", "Rome"], correct: 0 }
];
let score = 0, currentQuestionIndex = 0;
const questionElement = document.getElementById("question"), answersElement = document.getElementById("answers"), scoreElement = document.getElementById("score");
function loadQuestion() {
    const questionData = questions[currentQuestionIndex];
    questionElement.textContent = questionData.question;
    answersElement.innerHTML = "";
    questionData.answers.forEach((answer, index) => {
        const button = document.createElement("button");
        button.textContent = answer;
        button.onclick = () => checkAnswer(index);
        answersElement.appendChild(button);
    });
}
function checkAnswer(selectedIndex) {
    if (selectedIndex === questions[currentQuestionIndex].correct) score++;
    scoreElement.textContent = `Score: ${score}`;
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) loadQuestion(); else alert(`Le jeu est terminé ! Votre score est ${score}`);
}
window.onload = loadQuestion;